@extends('admin.layouts.home')

@section('content')
<link href="{{asset('/')}}css/add-coffee.css" rel="stylesheet">
<style>
    #productcoffee{
        border-color: #fff;
    }
</style>
<div class="wrapper wrapper-content animated fadeInRight">

    <section class="content-header">
        <h2 style="font-weight:bold;margin-top:-5px">
            Food
            <small>Add/ Edit Food</small>
        </h2>
        <ol class="breadcrumb" style="background-color:rgb(243,243,244);margin-bottom:10px">
            <li><a href="#"><i class="fas fa-tachometer-alt"></i> Home</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>
    <section class="content">


        <form id="addcoffee" method="post" enctype="multipart/form-data" action="{{url('admin/food')}}">
            {{ csrf_field() }}
            <div class="row">

                <div class="col-md-6">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h4>Food Details</h4>
                        </div>
                        <div class="ibox-content">



                            <div class="form-group {{ $errors->has('frame') ? ' has-error' : '' }}" >

                                <label >Food Name </label>
                                <input type="text"  autocomplete="off" name="name" id="name"  placeholder="Enter Food Name"  class="form-control"
                                       @if($errors->any())
                                       value="{{old('name')}}""
                                       @elseif(!empty($food->name))
                                       value="{{$food->name}}"
                                       @endif />

                            </div>
                            <div class="form-group {{ $errors->has('category') ? ' has-error' : '' }}" >
                                <label >Category </label>
                                <select name="category" id="category"  class="form-control">
                                    <option value="">--Select--</option>
                                    @foreach($category as $categories)
                                    <option value="{{$categories->id}}"
                                            @if($errors->any() && old('category') == $categories->id)
                                            selected
                                            @elseif(!empty($food->category_id) && $food->category_id == $categories->id)
                                            selected
                                            @endif
                                            >{{$categories->name}}
                                </option>
                                @endforeach

                            </select>
                            @if ($errors->has('category'))
                            <span class="help-block m-b-none">
                                <strong>{{ $errors->first('category') }}</strong>
                            </span>
                            @endif
                        </div>
                        <div class="form-group {{ $errors->has('subcategory') ? ' has-error' : '' }}" >
                            <label >Sub Category </label>

                            <select name="subcategory" id="subcategory"   class="form-control dynamic2">
                                <option value="">--Select Sub category--</option>
                                @foreach($subcategory as $categories)
                                <option value="{{$categories->id}}"
                                        @if($errors->any() && old('subcategory') == $categories->id)
                                        selected
                                        @elseif(!empty($food->subcategory_id) && $food->subcategory_id == $categories->id)
                                        selected
                                        @endif
                                        >{{$categories->name}}
                            </option>
                            @endforeach

                        </select>

                        @if ($errors->has('subcategory'))
                        <span class="help-block m-b-none">
                            <strong>{{ $errors->first('subcategory') }}</strong>
                        </span>
                        @endif


                    </div>

                    <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                        <label>Description</label>
                        <div>
                            <textarea class="form-control" id="description" rows="4" name="description" placeholder="Enter  Description"    @if($errors->any())
                                      value="{{old('description')}}""
                                      @elseif(!empty($food->description))
                                      value="{{$food->description}}"
                                      @endif ></textarea>


                        </div>
                        @if ($errors->has('price'))
                        <span class="help-block m-b-none">
                            <strong>{{ $errors->first('price') }}</strong>
                        </span>
                        @endif
                    </div>

                    <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                        <label>Price</label>
                        <div>
                            <input type="number"  autocomplete="off" name="price" id="price"  class="form-control" placeholder="Enter Price "
                                   @if($errors->any())
                                   value="{{old('price')}}""
                                   @elseif(!empty($food->price))
                                   value="{{$food->price}}"
                                   @endif />
                        </div>
                        @if ($errors->has('price'))
                        <span class="help-block m-b-none">
                            <strong>{{ $errors->first('price') }}</strong>
                        </span>
                        @endif
                    </div>

                    <div class="row coffe_sizes" >
                        <div style="background-color: green;">
                            <div class="col-md-4">

                                <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                                    <label>Small</label>
                                    <div>
                                        <input type="number" step="any"  autocomplete="off" name="small" id="small"  class="form-control" placeholder="Enter Price "
                                               @if($errors->any())
                                               value="{{old('price')}}""
                                               @elseif(!empty($food->price))
                                               value="{{$food->price}}"
                                               @endif />
                                    </div>
                                    @if ($errors->has('price'))
                                    <span class="help-block m-b-none">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-4">

                                <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                                    <label>Medium</label>
                                    <div>
                                        <input type="number" step="any" autocomplete="off" name="medium" id="medium"  class="form-control" placeholder="Enter Price "
                                               @if($errors->any())
                                               value="{{old('price')}}""
                                               @elseif(!empty($food->price))
                                               value="{{$food->price}}"
                                               @endif />
                                    </div>
                                    @if ($errors->has('price'))
                                    <span class="help-block m-b-none">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-4">

                                <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                                    <label>Large</label>
                                    <div>
                                        <input type="number" step="any" autocomplete="off" name="large" id="large"  class="form-control" placeholder="Enter Price "
                                               @if($errors->any())
                                               value="{{old('price')}}""
                                               @elseif(!empty($food->price))
                                               value="{{$food->price}}"
                                               @endif />
                                    </div>
                                    @if ($errors->has('price'))
                                    <span class="help-block m-b-none">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="form-group " >
                        <label for="state">Milk Pricess</label>
                       
                        <div class="col-md-12" style="background-color: #e0e0e0;padding-top:10px">
                            
                            <div class="col-md-4">
                                <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                                    <label>Full cream</label>
                                    <div>
                                        <input type="number" step="any" autocomplete="off" name="fullCream" id="fullCream"  class="form-control" placeholder="Enter Price "
                                               @if($errors->any())
                                               value="{{old('price')}}""
                                               @elseif(!empty($food->price))
                                               value="{{$food->price}}"
                                               @endif />
                                    </div>
                                    @if ($errors->has('price'))
                                    <span class="help-block m-b-none">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                                    <label>Skim</label>
                                    <div>
                                        <input type="number" step="any" autocomplete="off" name="skim" id="skim"  class="form-control" placeholder="Enter Price "
                                               @if($errors->any())
                                               value="{{old('price')}}""
                                               @elseif(!empty($food->price))
                                               value="{{$food->price}}"
                                               @endif />
                                    </div>
                                    @if ($errors->has('price'))
                                    <span class="help-block m-b-none">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                                    <label>Soy</label>
                                    <div>
                                        <input type="number" step="any" autocomplete="off" name="soy" id="soy"  class="form-control" placeholder="Enter Price "
                                               @if($errors->any())
                                               value="{{old('price')}}""
                                               @elseif(!empty($food->price))
                                               value="{{$food->price}}"
                                               @endif />
                                    </div>
                                    @if ($errors->has('price'))
                                    <span class="help-block m-b-none">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                                    <label>Almond</label>
                                    <div>
                                        <input type="number" step="any" autocomplete="almond" name="almond" id="almond"  class="form-control" placeholder="Enter Price "
                                               @if($errors->any())
                                               value="{{old('price')}}""
                                               @elseif(!empty($food->price))
                                               value="{{$food->price}}"
                                               @endif />
                                    </div>
                                    @if ($errors->has('price'))
                                    <span class="help-block m-b-none">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group {{ $errors->has('price') ? ' has-error' : '' }}" >

                                    <label>Oat</label>
                                    <div>
                                        <input type="number" step="any" autocomplete="off" name="oat" id="oat"  class="form-control" placeholder="Enter Price "
                                               @if($errors->any())
                                               value="{{old('price')}}""
                                               @elseif(!empty($food->price))
                                               value="{{$food->price}}"
                                               @endif />
                                    </div>
                                    @if ($errors->has('price'))
                                    <span class="help-block m-b-none">
                                        <strong>{{ $errors->first('price') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>





                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Food Image</h5>
                </div>
                <div class="ibox-content">
                    <div class="form-group  {{ $errors->has('coffee-photo') ? ' has-error' : '' }}" >
                        <?php $path = 'images/food/'; ?>
                        <img id="coffee-photo" class="bevel-black" src="{{asset('/')}}images/upload.png"
                             @if($errors->any())
                             value="{{old('food-photo')}}""
                             @elseif(!empty($food->img))
                             src="{{asset($path.$food->img)}}"
                             @endif >


                    </div>




                    <div class="form-group {{ $errors->has('frame') ? ' has-error' : '' }}" >

                        <label >Food Name </label>
                        <div class="{{ $errors->has('frame') ? ' has-error' : '' }}">
                            <div class="input-group">
                                <label class="input-group-btn">
                                    <span class="btn btn-primary" onclick="$('#dasd').trigger('click');">
                                        Browse
                                    </span>

                                </label>
                                <input id="fileinput" type="text" class="form-control" readonly="" value="@if(isset($food->img)) {{$food->img}} @endif ">

                                <input type="file"  autocomplete="off" name="food" onchange="preview(event)" accept="image/*" value="@if(isset($food->img)) {{$food->img}} @endif " id="dasd" class="form-control"  style="display:none" />

                            </div>
                            @if ($errors->has('frame'))
                            <span class="help-block m-b-none">
                                <strong>{{ $errors->first('frame') }}</strong>
                            </span>
                            @endif
                        </div>

                    </div>
                </div>
            </div>

        </div>


    </div>
    <button type="submit" class="btn btn-success">Add Food</button>
    <button type="reset" name="reset" class="btn btn-danger">
        <i class="glyphicon glyphicon-trash"></i>
        Clear</button>
</form>
<br/>
</section>
</div>
<script>
    var coffeeurl = '@if(isset($food)) {{asset("images/food/".$food->img)}} @endif';
    $("#dasd").on("change", function () {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader)
            return;
        $('#fileinput').val(this.files.length ? this.files[0].name : '');
        if (/^image/.test(files[0].type)) {
            var reader = new FileReader();
            reader.readAsDataURL(files[0]);
            reader.onloadend = function () {

                coffeeurl = this.result;
            }
        }
    });


</script>
<script type="text/javascript">
    function preview(event) {
        var selectedFile = event.target.files[0];
        var reader = new FileReader();
        var imgtag = document.getElementById("coffee-photo");
        reader.onload = function (event) {
            imgtag.src = event.target.result;
        };
        reader.readAsDataURL(selectedFile);
    }
</script>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
<script type="text/javascript">

    $(document).ready(function () {


        $('.dynamic2').change(function () {
            if ($(this).val() != '') {
                var select = $(this).attr("id");
                var value = $(this).val();
                if (value == 16) {
                    $(".coffe_sizes").show();
                    // var oust=document.getElementById("oust").value;
                    // var installemt_val=parseFloat(oust)/6

                    // document.getElementById("inst").value=installemt_val;
                } else {
                    // document.getElementById("inst").value=0;
                    $(".coffe_sizes").hide();
                }



            }


        });
    });


</script>
@endsection