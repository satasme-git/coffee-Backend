<?php

namespace App\Models;
use App\Models\Orders;
use App\Models\OrderFoods;
use App\Models\Users;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    protected $table = 'users';
}
