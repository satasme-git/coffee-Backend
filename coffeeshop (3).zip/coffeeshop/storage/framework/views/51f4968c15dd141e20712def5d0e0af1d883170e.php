<div class="footer">
            <div class="pull-right">
                
            </div>
            <div>
                <strong>Copyright</strong> &copy; <?php echo e(date('Y')); ?>

            </div>
        </div>
        <?php /**PATH C:\xampp\htdocs\Coffe shop\coffeeshop\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>