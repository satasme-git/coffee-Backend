

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('/')); ?>css/add-user.css" rel="stylesheet">
<style>
    #productcoffee{
        border-color: #fff;
    }
</style>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Add/Edit Customers</h5>
                </div>
                <div class="ibox-content">
                    <form id="addcoffee" method="post" enctype="multipart/form-data" action="<?php echo e(url('admin/customers')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-6">
                                    <?php $path='images/users/'; ?>
                                    <img id="user-photo" class="bevel-black" src="<?php echo e(asset('/')); ?>images/upload.png" >

                            </div>
                            <div class="col-md-6">
                                <div class="form-group clearfix">
                                    <label>User Image</label>
                                    <div class="<?php echo e($errors->has('frame') ? ' has-error' : ''); ?>">
                                        <div class="input-group">
                                            <label class="input-group-btn">
                                                <span class="btn btn-primary" onclick="$('#dasd').trigger('click');">
                                                    Browse 
                                                </span>

                                            </label>
                                            <input id="fileinput" type="text" class="form-control" readonly="" value="<?php if(isset($records->img)): ?> <?php echo e($records->img); ?> <?php endif; ?> ">

                                            <input type="file"  autocomplete="off" name="user" onchange="preview(event)" accept="image/*" value="<?php if(isset($records->img)): ?> <?php echo e($records->img); ?> <?php endif; ?> " id="dasd" class="form-control"  style="display:none" />

                                        </div>
                                        <?php if($errors->has('frame')): ?>
                                        <span class="help-block m-b-none">
                                            <strong><?php echo e($errors->first('frame')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <label >Customer Name </label>
                                        <input type="text"  autocomplete="off" name="name" id="name"  class="form-control"  
                                                   <?php if($errors->any()): ?>
                                                   value="<?php echo e(old('name')); ?>"" 
                                                   <?php elseif(!empty($records->name)): ?> 
                                                   value="<?php echo e($records->name); ?>" 
                                                   <?php endif; ?> />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <label >E-Mail</label>
                                        <input type="text"  autocomplete="off" name="email" id="email"  class="form-control"  
                                                   <?php if($errors->any()): ?>
                                                   value="<?php echo e(old('name')); ?>"" 
                                                   <?php elseif(!empty($records->email)): ?> 
                                                   value="<?php echo e($records->email); ?>" 
                                                   <?php endif; ?> />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <label >Mobile Number</label>
                                        <input type="text"  autocomplete="off" name="mobile_no" id="mobile_no"  class="form-control"  
                                                   <?php if($errors->any()): ?>
                                                   value="<?php echo e(old('name')); ?>"" 
                                                   <?php elseif(!empty($records->mobile_no)): ?> 
                                                   value="<?php echo e($records->mobile_no); ?>" 
                                                   <?php endif; ?> />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                    <label >Status </label>
                                        <div class="form-group <?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                                            <div>
                                                <select name="status" id="status"  class="form-control">  
                                                    <option value="">--Select--</option>
                                                    <option 
                                                    <?php if(!empty($records->status)): ?> value="<?php echo e($records->status); ?>"<?php endif; ?> 
                                                    <?php if(!empty($records->status) && $records->status == '0'): ?> selected <?php endif; ?>>
                                                    Active
                                                    </option>
                                                    <option 
                                                    <?php if(!empty($records->status)): ?> value="<?php echo e($records->status); ?>"<?php endif; ?> 
                                                    <?php if(!empty($records->status) && $records->status == '1'): ?> selected <?php endif; ?>>
                                                    Blacklist
                                                    </option>
                                                    
                                                </select>
                                        </div>
                                        <?php if($errors->has('status')): ?>
                                        <span class="help-block m-b-none">
                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                
                            </div>
                            <div class="">
                                <div class="col-md-6">
                                    <div class="form-group" >
                                        <button class="btn btn-sm btn-primary" type="submit">Save</button>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <?php if(!empty($records->id)): ?>
                    <input type="hidden" name="id" value="<?php echo e($records->id); ?>">
                    <?php endif; ?>
                </form>
            </div>

        </div>


        </div>
    </div>
</div>
<script>
    // var coffeeurl = '<?php if(isset($records)): ?> <?php echo e(asset("images/users/".$records->name)); ?> <?php endif; ?>';
    $("#dasd").on("change", function(){
    var files = !!this.files ? this.files : [];
    if (!files.length || !window.FileReader) return;
    $('#fileinput').val(this.files.length ? this.files[0].name : '');
    if (/^image/.test(files[0].type)) {
    var reader = new FileReader();
    reader.readAsDataURL(files[0]);
    reader.onloadend = function(){

    coffeeurl = this.result;
    }
    }
    });
    
    
</script>
<script type="text/javascript">
    function preview(event){
        var selectedFile = event.target.files[0];
        var reader = new FileReader();
        var imgtag = document.getElementById("user-photo");
        reader.onload = function(event) {
            imgtag.src = event.target.result;
        };
        reader.readAsDataURL(selectedFile);
    }
</script>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Coffe shop\coffeeshop\resources\views/admin/addUsers.blade.php ENDPATH**/ ?>