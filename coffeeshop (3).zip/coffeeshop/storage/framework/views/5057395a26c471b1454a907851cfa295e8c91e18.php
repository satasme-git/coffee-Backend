<div class="footer">
            <div class="pull-right">
                
            </div>
            <div>
                <strong>Copyright</strong> &copy; <?php echo e(date('Y')); ?>

            </div>
        </div>
        <?php /**PATH E:\laravelHome\coffeeshop\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>