<div class="footer">
            <div class="pull-right">
                
            </div>
            <div>
                <strong>Copyright</strong> &copy; {{date('Y')}}
            </div>
        </div>
        