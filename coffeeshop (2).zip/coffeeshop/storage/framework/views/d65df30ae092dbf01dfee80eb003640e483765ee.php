

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('/')); ?>css/add-coffee.css" rel="stylesheet">
<style>
    #productcoffee{
        border-color: #fff;
    }
</style>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Add/Edit Coffee</h5>
                </div>
                <div class="ibox-content">
                    <form id="addcoffee" method="post" enctype="multipart/form-data" action="<?php echo e(url('admin/coffee')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-6">
                               
                            <?php $path='images/coffee/'; ?>
                                    <img id="coffee-photo" class="bevel-black" src="<?php echo e(asset('/')); ?>images/upload.png" 
                                            <?php if($errors->any()): ?>
                                                   value="<?php echo e(old('coffee-photo')); ?>"" 
                                                   <?php elseif(!empty($coffee->img)): ?> 
                                                   src="<?php echo e(asset($path.$coffee->img)); ?>"
                                                   <?php endif; ?> >

                            </div>
                            <div class="col-md-6">
                                <div class="form-group clearfix">
                                    <label>Coffee Image</label>
                                    <div class="<?php echo e($errors->has('frame') ? ' has-error' : ''); ?>">
                                        <div class="input-group">
                                            <label class="input-group-btn">
                                                <span class="btn btn-primary" onclick="$('#dasd').trigger('click');">
                                                    Browse 
                                                </span>

                                            </label>
                                            <input id="fileinput" type="text" class="form-control" readonly="" value="<?php if(isset($coffee->img)): ?> <?php echo e($coffee->img); ?> <?php endif; ?> ">

                                            <input type="file"  autocomplete="off" name="coffee" onchange="preview(event)" accept="image/*" value="<?php if(isset($coffee->img)): ?> <?php echo e($coffee->img); ?> <?php endif; ?> " id="dasd" class="form-control"  style="display:none" />

                                        </div>
                                        <?php if($errors->has('frame')): ?>
                                        <span class="help-block m-b-none">
                                            <strong><?php echo e($errors->first('frame')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <label >Coffee Name </label>
                                        <input type="text"  autocomplete="off" name="name" id="name"  class="form-control"  
                                                   <?php if($errors->any()): ?>
                                                   value="<?php echo e(old('name')); ?>"" 
                                                   <?php elseif(!empty($coffee->name)): ?> 
                                                   value="<?php echo e($coffee->name); ?>" 
                                                   <?php endif; ?> />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <label >Category </label>
                                        <div class="form-group <?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                                            <div>
                                                <select name="category" id="category"  class="form-control">  
                                                    <option value="">--Select--</option>
                                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($categories->id); ?>"
                                                            <?php if($errors->any() && old('category') == $categories->id): ?>
                                                            selected
                                                            <?php elseif(!empty($coffee->category_id) && $coffee->category_id == $categories->id): ?> 
                                                            selected
                                                            <?php endif; ?> 
                                                            ><?php echo e($categories->name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                 
                                            </select>
                                        </div>
                                        <?php if($errors->has('category')): ?>
                                        <span class="help-block m-b-none">
                                            <strong><?php echo e($errors->first('category')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group <?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                                        <label>Description</label>
                                        <div>
                                            <input type="text"  autocomplete="off" name="description" id="description"  class="form-control"  
                                                   <?php if($errors->any()): ?>
                                                   value="<?php echo e(old('description')); ?>"" 
                                                   <?php elseif(!empty($coffee->description)): ?> 
                                                   value="<?php echo e($coffee->description); ?>" 
                                                   <?php endif; ?> />
                                        </div>
                                        <?php if($errors->has('title')): ?>
                                        <span class="help-block m-b-none">
                                            <strong><?php echo e($errors->first('title')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group <?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                                        <label>Price</label>
                                        <div>
                                            <input type="number"  autocomplete="off" name="price" id="price"  class="form-control"  
                                                   <?php if($errors->any()): ?>
                                                   value="<?php echo e(old('price')); ?>"" 
                                                   <?php elseif(!empty($coffee->price)): ?> 
                                                   value="<?php echo e($coffee->price); ?>" 
                                                   <?php endif; ?> />
                                        </div>
                                        <?php if($errors->has('price')): ?>
                                        <span class="help-block m-b-none">
                                            <strong><?php echo e($errors->first('price')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="">
                                <div class="col-md-6">
                                    <div class="form-group" >
                                        <button class="btn btn-sm btn-primary" type="submit">Save</button>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <?php if(!empty($coffee->id)): ?>
                    <input type="hidden" name="id" value="<?php echo e($coffee->id); ?>">
                    <?php endif; ?>
                </form>
            </div>

        </div>


    </div>
</div>
</div>
<script>
    var coffeeurl = '<?php if(isset($coffee)): ?> <?php echo e(asset("images/coffee/".$coffee->img)); ?> <?php endif; ?>';
    $("#dasd").on("change", function(){
    var files = !!this.files ? this.files : [];
    if (!files.length || !window.FileReader) return;
    $('#fileinput').val(this.files.length ? this.files[0].name : '');
    if (/^image/.test(files[0].type)) {
    var reader = new FileReader();
    reader.readAsDataURL(files[0]);
    reader.onloadend = function(){

    coffeeurl = this.result;
    }
    }
    });
    
    
</script>
<script type="text/javascript">
    function preview(event){
        var selectedFile = event.target.files[0];
        var reader = new FileReader();
        var imgtag = document.getElementById("coffee-photo");
        reader.onload = function(event) {
            imgtag.src = event.target.result;
        };
        reader.readAsDataURL(selectedFile);
    }
</script>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Coffe shop\coffeeshop\resources\views/admin/addCoffee.blade.php ENDPATH**/ ?>