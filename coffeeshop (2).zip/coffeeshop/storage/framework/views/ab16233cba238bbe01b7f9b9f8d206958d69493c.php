<?php $__env->startSection('content'); ?>
<!-- <link href="<?php echo e(url('/')); ?>/css/plugins/dataTables/datatables.css"> -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css">

 <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <a  href="<?php echo e(url('admin/addslides/0')); ?>" class="btn btn-primary pull-right">Add new</a>
                    </div>
					
                    <div class="ibox-content" style="margin-top:1%">
					<?php if(Session::has('msg')): ?>
					<?php echo Session::get('msg'); ?> 
					<?php endif; ?>
					
					
                        <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover dataTables-example" >
                    <thead>
                    <tr>
						<th>Thumb</th>
						<th>Description</th>
						<th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
					<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                    <td>
						<?php if(!empty($row->thumb) && file_exists(public_path($row->thumb))): ?>
							<img src="<?php echo e(asset($row->thumb)); ?>" style="width:52px;height:52px;">
						<?php endif; ?>
						</td>
                        <td>
                            <?php echo e($row->description); ?>

                        </td>
                        <td>
							<button onclick="deleteconfirm(<?php echo e($row->id); ?>)" class="btn btn-danger"><i class="fa fa-trash-o"></i></button>
						</td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Thumb</th>
						<th>Description</th>
						<th>Action</th>
                       
                    </tr>
                    </tfoot>
                    </table>
                        </div>

                    </div>
                </div>
            </div>
            </div>
         </div>
	<!-- <script src="<?php echo e(url('/')); ?>/js/plugins/dataTables/datatables.min.js"></script> -->
    <script src="<?php echo e(url('/')); ?>/js/plugins/bootbox/bootbox.min.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>
	<script>
        $(document).ready(function(){
            $('.dataTables-example').DataTable();

        });
		function deleteconfirm(id){
			bootbox.confirm({
				title: "Delete Record",
				message: "Are you sure you want to delete?",
				buttons: {
					confirm: {
						label: 'Yes',
						className: 'btn-success'
					},
					cancel: {
						label: 'No',
						className: 'btn-danger'
					}
				},
				callback: function (result) {
					if(result){
						window.location.href='<?php echo e(url("admin/deleteslides")); ?>'+'/'+id;
					}
				}
			});
		}
       
    </script>
         <?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Coffe shop\coffeeshop\resources\views/admin/slides.blade.php ENDPATH**/ ?>