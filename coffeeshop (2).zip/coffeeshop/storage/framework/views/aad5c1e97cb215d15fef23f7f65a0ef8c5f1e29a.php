

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('/')); ?>css/add-coffee.css" rel="stylesheet">
<style>
#productcoffee {
    border-color: #fff;
}
</style>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-md-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>View Food Orders</h5>
                </div>

                <?php if(session('alert')): ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="fcoffee" onclick="freeCoffee(<?php echo e($order->id); ?>)">abc </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <script type="text/javascript">
                function freeCoffee(id) {
                    bootbox.confirm({
                        title: "Free Coffee",
                        message: "Are you sure you want to give free coffee?",
                        buttons: {
                            confirm: {
                                label: 'Yes',
                                className: 'btn-success'
                            },
                            cancel: {
                                label: 'No',
                                className: 'btn-danger'
                            }
                        },
                        callback: function(result) {
                            if (result) {
                                window.location.href = '<?php echo e(url("admin/acceptfreecoffee")); ?>' + '/' +
                                    id;
                            } else {
                                window.location.href = '<?php echo e(url("admin/denyfreecofee")); ?>' + '/' + id;
                            }
                        }
                    });
                }
                var elem = document.getElementById("fcoffee");
                if (typeof elem.onclick == "function") {
                    elem.onclick.apply(elem);
                }
                </script>
                <?php endif; ?>

                <div class="ibox-content">
                    <!-- <form id="addcoffee" method="post" enctype="multipart/form-data" action="<?php echo e(url('admin/food')); ?>"> -->
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="col-md-12"><b>Order No: <?php echo e($order->orderid); ?></b></div>
                                <div class="col-md-12" style="margin-top:2%"><b>Customer: <?php echo e($order->users->name); ?></b>
                                </div>
                                <div class="col-md-12" style="margin-top:2%">
                                    <b>
                                        Order Status:
                                        <?php if($order->status==0): ?>
                                        Order Cancelled
                                        <?php elseif($order->status==1): ?>
                                        Pending Order
                                        <?php elseif($order->status==2): ?>
                                        Order Placed
                                        <?php elseif($order->status==3): ?>
                                        Free coffee Given
                                        <?php endif; ?>
                                    </b>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <table class="table table-striped table-bordered table-hover dataTables-example"
                            style="margin-top:2%">
                            <thead>
                                <tr>
                                    <th>Food</th>
                                    <th>qty</th>
                                    <th>price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $path='images/food/'; ?>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <?php $__currentLoopData = $order->orderfoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderfoods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($orderfoods->foods->name); ?></td>
                                    <td><?php echo e($orderfoods->qty); ?></td>
                                    <td><?php echo e(money_formate($orderfoods->price)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="col-md-3"></div>
                                <div class="col-md-3"></div>
                                <div class="col-md-3"></div>
                                <div class="col-md-3" style="float:left"><b>Total: <?php echo e(money_formate($order->total)); ?></b>
                                </div>
                            </div>
                        </div>
                        <?php if($order->status==1): ?>
                        <form method="GET" action="<?php echo e(url('admin/purchasefood/'.$order->id)); ?>">
                            <div class="row" style="margin-top:2%">
                                <div class="col-md-12">
                                    <div class="col-md-3"></div>
                                    <div class="col-md-3"></div>
                                    <div class="col-md-3"></div>
                                    <div class="col-md-3" style="float:left"><button class="btn-danger"
                                            style="margin-left:10%" type="submit">Purchase</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- <div class="">
                                <div class="col-md-6">
                                    <div class="form-group" >
                                        <button class="btn btn-sm btn-primary" type="submit">Save</button>
                                    </div>
                                </div>

                            </div> -->

                    </div>
                </div>

                <!-- </form> -->
            </div>

        </div>


    </div>
</div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Coffe shop\coffeeshop\resources\views/admin/viewFood.blade.php ENDPATH**/ ?>