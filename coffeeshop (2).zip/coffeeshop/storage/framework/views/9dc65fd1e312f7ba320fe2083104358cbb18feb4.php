<div id="right-sidebar">
            
        </div>
    <?php /**PATH C:\xampp\htdocs\Coffe shop\coffeeshop\resources\views/admin/includes/rightsidebar.blade.php ENDPATH**/ ?>