<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Coffee Shop</title>

   <link href="<?php echo e(URL::asset('')); ?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(URL::asset('')); ?>css/font-awesome.css" rel="stylesheet">

    <link href="<?php echo e(URL::asset('')); ?>css/admin/animate.css" rel="stylesheet">
    <link href="<?php echo e(URL::asset('')); ?>css/admin/style.css" rel="stylesheet">
    <link href="<?php echo e(URL::asset('')); ?>css/chosen.css" rel="stylesheet">
	 <script src="<?php echo e(URL::asset('')); ?>js/jquery.1.12.4.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script>
     <script src="<?php echo e(url('/')); ?>/js/plugins/bootbox/bootbox.min.js"></script>

</head>

<?php /**PATH C:\xampp\htdocs\Coffe shop\coffeeshop\resources\views/admin/includes/head.blade.php ENDPATH**/ ?>