<?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <div id="wrapper">
    <?php echo $__env->make('admin.includes.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="page-wrapper" class="gray-bg">
		 <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		 <?php echo $__env->yieldContent('content'); ?>
         <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
        <?php echo $__env->make('admin.includes.rightsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

    <!-- Mainly scripts -->
    <script src="<?php echo e(url('/')); ?>/js/plugins/metisMenu/jquery.metisMenu.js"></script>
   <script src="<?php echo e(url('/')); ?>/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo e(url('/')); ?>/js/admin/narmadatech.js"></script>
  

    <script>
        $(document).ready(function() {
            
        });
    </script>
</body>
</html>
<?php /**PATH E:\laravelHome\coffeeshop\resources\views/admin/layouts/home.blade.php ENDPATH**/ ?>